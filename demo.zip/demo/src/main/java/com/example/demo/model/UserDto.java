package com.example.demo.model;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.example.demo.dao.UserRepository;
import com.google.common.base.Objects;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@Component
@ApiModel(value = "Model", description = "Model description")
public class UserDto {
	
	@Autowired
	private UserRepository userRepo;
		
	//private static final String swaggerUserName=userRepo.
	private  String username;
	private  String password;
	private int age;
	private int salary;
	
	@PostConstruct
	private void setSwaggerProperties() {
		 User user = userRepo.findAll().get(0);
         if(user != null) {
        	 SwaggerExamples swagger = new SwaggerExamples("Testing", "123@abc");
        	 this.username = user.getUsername();
         }
	}

	@ApiModelProperty(position = 1, required = true, notes = "User Name", example = "Testing ") 
	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	@ApiModelProperty(position = 2, required = true, notes = "Password", example = "test")
	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	@ApiModelProperty(position = 3, required = false, notes = "age", example = "26")
	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	@ApiModelProperty(position = 4, required = false, notes = "salary", example = "1234567")
	public int getSalary() {
		return salary;
	}

	public void setSalary(int salary) {
		this.salary = salary;
	}
}
