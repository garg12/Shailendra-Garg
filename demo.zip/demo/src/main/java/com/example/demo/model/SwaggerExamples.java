package com.example.demo.model;

import java.util.Map;

import org.springframework.data.annotation.Id;

public class SwaggerExamples {

	public final String username;
	public final String password;

	public SwaggerExamples(String username, String password) {

		// This keyword refers to current instance itself
		this.username = username;
		this.password = password;

	}

	public String getUsername() {
		return username;
	}

	public String getPassword() {
		return password;
	}
	
	

}
