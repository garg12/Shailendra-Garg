package com.example.demo.model;

/**
 * Auth Token Entity.
 * @author shailendragarg
 *
 */
public class AuthToken {

    private String token;
    private String message;

    public AuthToken(){
    }

    public AuthToken(String token, String message){
        this.token = token;
        this.message = message;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

}
