package com.example.demo.controller;

import java.util.Objects;
import java.util.logging.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.dao.UserRepository;
import com.example.demo.model.User;
import com.example.demo.model.UserDto;
import com.example.demo.service.UserServiceImpl;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponses;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/users")
public class UserController {
	private static Logger LOGGER = Logger.getLogger("UserController");
	 /**
     * This API is Responsible To Register New User.
     *
     * @param user
     * @return
     */
	@Autowired
	private UserServiceImpl userService;
	
	@Autowired
	private UserRepository userRepository;
	
	@ApiOperation(value = "Register New User", notes = "New User Registration Process")
    @PostMapping(value = "/registerUser", consumes = MediaType.APPLICATION_JSON_VALUE)
    private ResponseEntity<Object> registerUser(@RequestBody UserDto user) {
       LOGGER.info("User Registration in progress");
       try {
    	   userService.registerUser(user);
       	return new ResponseEntity<> ("User Registered Successfully", HttpStatus.CREATED);
       } catch(Exception e) {
    	 LOGGER.warning("Error While Registering the User: "+e.getMessage());
       }
      	return new ResponseEntity<> ("User Registration Failed", HttpStatus.BAD_REQUEST);
    }
    
    @PreAuthorize("hasRole('ADMIN')")
    @ApiOperation(value = "Fetch user",
    notes = "This Method Fetches User By UserName")
    @ApiParam(
    	    name =  "userName",
    	    type = "String",
    	    value = "userName for the user that need to be fetched",
    	    example = "shailgar",
    	    required = true)
    @GetMapping(value = "/getUser", consumes = MediaType.APPLICATION_JSON_VALUE)
    private ResponseEntity<Object> testUser(@RequestParam String userName) {
       LOGGER.info("Fetchiong User Details: "+userName);
    	return new ResponseEntity<>("Loggin in", HttpStatus.OK);
    }
    
    @PreAuthorize("hasAuthority('USER')")
    @GetMapping(value = "/getUsers", consumes = MediaType.APPLICATION_JSON_VALUE)
    private ResponseEntity<Object> testUsers() {
        LOGGER.info("Fetchiong User Details");
    	return new ResponseEntity<>("Testing", HttpStatus.OK);
    }
    
    @PreAuthorize("hasAuthority('ADMIN')")
    @GetMapping(value = "/testUsers", consumes = MediaType.APPLICATION_JSON_VALUE)
    private ResponseEntity<Object> testUsersagain() {
        LOGGER.info("Fetching User Details");
    	return new ResponseEntity<>("Testing-again", HttpStatus.OK);
    }


}
