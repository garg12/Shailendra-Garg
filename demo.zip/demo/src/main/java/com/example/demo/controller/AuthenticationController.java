package com.example.demo.controller;

import java.util.logging.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import com.example.demo.dao.UserRepository;
import com.example.demo.jwt.TokenProvider;
import com.example.demo.model.AuthToken;
import com.example.demo.model.LoginUser;
import com.example.demo.model.User;
import com.example.demo.service.UserServiceImpl;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/token")
public class AuthenticationController {
	private static Logger LOGGER = Logger.getLogger("AuthenticationController");

   @Autowired
   private AuthenticationManager authenticationManager;

    @Autowired
    private TokenProvider jwtTokenUtil;

    @Autowired
    private UserServiceImpl userService;

    @RequestMapping(value = "/generate-token", method = RequestMethod.POST)
    public ResponseEntity<?> register(@RequestBody LoginUser loginUser) throws AuthenticationException {
   
    	try {
    		 final Authentication authentication = authenticationManager.authenticate(
    	                new UsernamePasswordAuthenticationToken(
    	                        loginUser.getUsername(),
    	                        loginUser.getPassword()
    	                )
    	        );
    	        SecurityContextHolder.getContext().setAuthentication(authentication);
    	        final String token = jwtTokenUtil.generateToken(authentication);
    	        return ResponseEntity.ok(new AuthToken(token, " Hurrah !! Kindly have your Auth Token"));
    	} catch (Exception e) {
    		LOGGER.warning("Exception Occurred While generating Auth Token"+e.getMessage());
    	}
        return new ResponseEntity<>("Sorry !! ", HttpStatus.BAD_REQUEST);
    }
    
    @GetMapping(value = "/getUser")
    private ResponseEntity<Object> getUser(@RequestParam String userName) {
       LOGGER.info("User has been loggedIn Successfully");
       User user =userService.getUserByUserName(userName);
       return new ResponseEntity<>(user, HttpStatus.OK);
    }

}
